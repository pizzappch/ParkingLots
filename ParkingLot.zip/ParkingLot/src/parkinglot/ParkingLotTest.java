import java.sql.Timestamp;
import java.util.Scanner;


public class ParkingLotTest {



    public static void main(String[] args) {
        System.out.println("===============");
        System.out.println("Start ADMIN PC");
        System.out.println("===============");

        Scanner sc = new Scanner(System.in);

        System.out.print("Total Free Parking Number:");
        int tcar = sc.nextInt();
        System.out.print("Now, Free Parking Number:");
        int fcar = sc.nextInt();
        ParkingLot pkl = new ParkingLot(tcar, fcar);
        Vehicle[] cars = new Vehicle[100]; // cars 1-100

        System.out.println("Total Free Parking Number:" + tcar);
        System.out.println("Now, Free Parking Number:" + fcar);

        int ticketID;
        int input = -2;
        int num = 0;
        int i=1;
        int tcar1;
        int fcar1;
        while (input != 3) {
            System.out.println("=============================Transaction : " + ++num + "=============================");
            System.out.println("Start(0) | Car in(1) | Car out(2) | Shutdown(3) | Reset(4) | Restart(5)");
            input = sc.nextInt();
            
            switch (input) {
                case 0:
                    pkl.start();
                    break;
                case 1:
                    // Save each car to each array varibale 
                    //Plate
                    cars[i] = new Vehicle();
                    String numberPlate = cars[i].setNumberPlate();
                    //Number wheels
                    
                    
                    cars[i] = new Vehicle();
                    int numberWheels = cars[i].setNumberWheels();
                    //Time Hour h and minutes
                                       
                    String time = cars[i].setTime();
                   
                    cars[i].setTicketID(i);
                                       
                    pkl.countCarInSide();
                    //
                    
                    System.out.println("You have been added"
                            + "\nNumber Plate : "+numberPlate+""
                            + "\nNumberWheels : "+numberWheels+""        
                            + "\nTime : "+time+""
                            + "\nTicketID : "+i);
                    
                    i=i+1;
                    
                    break;
                    
                case 2:
                    System.out.print("Insert cust ticket id: ");
                    int out = sc.nextInt();//0
                    System.out.println("Cost for ticket id:"+out+" is "+cars[out].getCost());
                    
                    pkl.countCarOutSide();
                    break;
                case 3:
                    pkl.shutDown();
                    break;
                case 4:
                    pkl.reset();
                    break;
                case 5:
                    System.out.print("Total Free Parking Number:");
                    tcar1 = sc.nextInt();
                    System.out.print("\nNow, Free Parking Number:");
                    fcar1 = sc.nextInt();
                    pkl.restart(tcar1, fcar1);
                    System.out.println("\nTotal Free Parking Number:" + tcar1);
                    System.out.println("Now, Free Parking Number:" + fcar1);
                    break;
                default:
                    pkl.error();
            }
            //System.out.println(pkl);
        }
        System.out.println("=========================================================================");
        
    }
    
}

 

 

 

 

 

 

 

/*Scanner sc = new Scanner(System.in);//declare varible named "sc" as Scanner data type for get data from keyboard   
        //set total = 5 
        ParkingLot p = new ParkingLot(5);
        // test Car in = 2
        p.countCarInSide(2);
        // test Car out = 1
        p.countCarOutSide(1);
        //show freeparking
        p.showFreePark();
            System.out.println(p);
    }

 

 

 

 

 

 

 

}*/