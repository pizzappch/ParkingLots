import java.sql.Time;
import java.util.Scanner;

 

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hpcom
 */
public class ServiceCharge {

    private int costWhenOverFreeForTwoWheel = 10;
    private int costWhenOverFreeForThreeWheel = 30;
    private int costWhenOverFreeForFourWheel = 30;


    public int getCostWhenOverFreeForTwoWheel() {
        return costWhenOverFreeForTwoWheel;
    }

 

    public int getCostWhenOverFreeForThreeWheel() {
        return costWhenOverFreeForThreeWheel;
    }

 

    public int getCostWhenOverFreeForFourWheel() {
        return costWhenOverFreeForFourWheel;
    }
    

    public void setCostWhenOverFreeForTwoWheel(int costWhenOverFreeForTwoWheel) {
        this.costWhenOverFreeForTwoWheel = costWhenOverFreeForTwoWheel;
    }

 

    public void setCostWhenOverFreeForThreeWheel(int costWhenOverFreeForThreeWheel) {
        this.costWhenOverFreeForThreeWheel = costWhenOverFreeForThreeWheel;
    }

 

    public void setCostWhenOverFreeForFourWheel(int costWhenOverFreeForFourWheel) {
        this.costWhenOverFreeForFourWheel = costWhenOverFreeForFourWheel;
    }

 

    public float getCost(Time t, int numberWheels) {
        //TOTAL PARKING TIME > X hour 
        float cost = 0;
        Time latestTime = new Time(System.currentTimeMillis());
        System.out.println("latestTime:"+latestTime.toString());
        System.out.println("Time of car in:"+t.toString());
//            int h = t.getHours();
//            int m = t.getMinutes();


                int wn = -1;
                Scanner sc = new Scanner(System.in);
                while (wn != 2 && wn != 3 && wn != 4) {
                    //sout Please Check Wheels again
                    System.out.println("Please Check Wheels again!!");
                    //sout  How many wheel for this car?
                    System.out.print("How many wheel for this car?:");
                    //input wheels number into wn variable
                    wn = sc.nextInt();
                    switch (wn) {
                        case 2: cost = this.getCostWhenOverFreeForTwoWheel();
                            break;

                        case 3: cost = this.getCostWhenOverFreeForFourWheel();
                            break;

                        case 4:
                                cost = this.getCostWhenOverFreeForFourWheel();
                            break;

                        default:                                
                            break;
                    }
        }
        return cost;

 

    }
}