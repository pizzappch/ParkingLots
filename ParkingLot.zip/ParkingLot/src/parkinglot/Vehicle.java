import java.util.Scanner;
import java.sql.Time;

 

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hpcom
 */
public class Vehicle {

 

    private String numberPlate;
    private int ticketID;
    private int numberWheels;
    private float cost;
    private Time time;

 

    public Vehicle() {

 

    }

 

    public String setNumberPlate() {
        Scanner sc = new Scanner(System.in);

 

//        String[] myArray = new String[car];
        System.out.println("Enter the License plate:");
        this.numberPlate = sc.next();

        return numberPlate;
 
    }

 

    public int setNumberWheels(int numberWheels) {
        this.numberWheels = numberWheels;
        return numberWheels;
    }
    
    public int setNumberWheels() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the number of wheels :");
        this.numberWheels = sc.nextInt();

        return numberWheels;
    }

 

    public void setCost(float cost) {
        this.cost = cost;
    }

 

    public void setNumberPlate(String numberPlate) {
        this.numberPlate = numberPlate;
    }

 

    public void setTicketID(int ticketID) {
        this.ticketID = ticketID;

 

    }


    public String setTime() {

 
    
        Scanner sc = new Scanner(System.in);
        System.out.print("Time: "); // Time: 10:3
        int h = sc.nextInt();//Hour

        System.out.print(":");
        int m = sc.nextInt();//Minutes

        Time t = new Time(h, m, 0);

 

        this.time = t;
        String time = t.toString();

 

        return time;
    }

 

    public void setCost() {
        this.cost = cost;
    }

 

    public int getTicketID() {

 

        return this.ticketID;
    }

 

    public String getNumberPlate() {
        return numberPlate;
    }

 

    public float getCost() {
        ServiceCharge scg = new ServiceCharge();
        return scg.getCost(this.time, this.numberWheels);
    }

 

    public String getTimeInString() {
        return time.toString();
    }
    
    public Time getTime() {
        return time;
    }

 

}